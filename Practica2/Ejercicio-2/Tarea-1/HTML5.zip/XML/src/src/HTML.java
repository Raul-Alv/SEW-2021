package src;

import java.util.ArrayList;
import java.util.List;

import Componentes.Persona;
import Componentes.Ruta;

public class HTML{

	String ficheroFinal;

	public HTML() {
		Application a = new Application();
		ficheroFinal = generarHTML(a.getR());//cogemos los datos de las rutas
	}

	/**
	 * M�todo q me coge los datos leidos del xml y me lo convierte en html en formato String
	 * @param arbol
	 * @return
	 */
	public String generarHTML(List<Persona> arbol) {
		String archivo = "<!DOCTYPE html>" + "<html lang=\"es\">" + "<head><meta charset=\"UTF-8\"/>"
				+ "<title>Arbol genialogico</title></head>" + "<body>'\r\n"
				+ " <header><h1>Arbol genial�gico</h1></header>";
		fill(archivo, arbol);
		
		archivo = archivo + "\r\n"
				+ "    <footer>\r\n"
				+ "        <p>Autor: Laura Gonzalez Gonzalez<br>\r\n"
				+ "        <a href= \"mailto:lauragonzalez@gmail.com\">lauragonzalez@gmail.com</a>\r\n"
				+ "        </p>\r\n"
				+ "        </footer>";
		
		archivo = archivo + "</body>\r\n"
				+ "    </html>";
		
		return archivo;

	}
	
	private void fill(String archivo, List<Persona> arbol) {
		for(Persona p: arbol) {//recorremos todas las rutas que tenemos 
			archivo = archivo + "<section>\n" + "<h2> " + p.getNombre() + " " + p.getApellidos() + "</h2>\n";
			archivo = archivo + "<p> Fecha de nacimiento: " + p.getFehcaNacimiento() + "</p>\n";
			archivo = archivo + "<p> Coordenadas de nacimiento: " + p.getCoordenadasNacimiento(0) + " " + p.getCoordenadasNacimiento(1) +"</p>\n";
			if(p.getLugarFallecimiento() != null) {
				archivo = archivo + "<p> Lugar de fallecimiento: " + p.getLugarFallecimiento() + "</p>\n";
				archivo = archivo + "<p> Coordenadas de fallecimiento: " + p.getCoordenadasFallecimiento(0) + " " + p.getCoordenadasFallecimiento(1) + "</p>\n";
			}
			archivo = archivo + "<p> Fotografia: " + p.getFotografia() + "</p>\n";
			archivo = archivo + "<p> Agencia: " + p.getComentarios() + "</p>\n";
			if(p.getPadre() != null) {
				archivo = archivo + "<p> Padre: " + p.getPadre() + "</p>\n";
			}
			if(p.getMadre() != null) {
				archivo = archivo + "<p> Padre: " + p.getMadre() + "</p>\n";
			}
			archivo = archivo + "</section>";
			
			
		}
	}

	/**
	 * M�todo q me devuelve el String q contiene la informaci�n del fichero 
	 * @return
	 */
	public String getFicheroFinal() {
		return ficheroFinal;
	}
}
