package src;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import nu.xom.Builder;
import nu.xom.Document;
import nu.xom.Element;
import nu.xom.Elements;
import nu.xom.ParsingException;
import Componentes.Fotos;
import Componentes.Persona;
import Componentes.Referencias;
import Componentes.Ruta;

public class Application {

	Builder builder = null;
	Document doc = null;
	List<Persona> r = new ArrayList<Persona>();

	
	public Application() {
		cargarArchivos();// cargamos el fichero
		r = recorrerNodos();
	}

	public List<Persona> getR() {
		return r;
	}

	public void cargarArchivos() {
		// Creamos el builder XOM
		builder = new Builder();
		try {
			doc = builder.build(new FileInputStream("rutas.xml"));
		} catch (ParsingException | IOException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<Persona> recorrerNodos() {
		Element raiz = doc.getRootElement();// Obtenemos la etiqueta ra�z
		ArrayList<Persona> personas = new ArrayList<Persona>();//donde est�n almacenadas las rutas
		Elements hijosRaiz = raiz.getChildElements();// Recorremos los hijos de la etiqueta ra�z
		
		for (int i=0;i<hijosRaiz.size();i++) {
			Element hijo = hijosRaiz.get(i);
			String nombre = hijo.getAttributeValue("nombre");
			System.out.println(nombre);
			String apellidos = hijo.getFirstChildElement("tipo").getValue();
			String lugarNacimiento = hijo.getFirstChildElement("lugarNacimiento").getValue();
			String fechaNacimiento = hijo.getFirstChildElement("fechaNacimiento").getValue();
			Date fnac = new SimpleDateFormat("yyyy/mm/dd").parse(fechaNacimiento);
			String lugarFallecimiento = hijo.getFirstChildElement("lugarFallecimiento").getValue();
			String fechaFallecimiento = hijo.getFirstChildElement("fechaFallecimiento").getValue();
			Date ffa = new SimpleDateFormat("yyyy/mm/dd").parse(fechaFallecimiento);
			String fotografia = hijo.getFirstChildElement("fotografia").getValue();
			String comentarios = hijo.getFirstChildElement("comentarios").getValue();
			String padre = hijo.getFirstChildElement("persona").getValue();
			String madre = hijo.getFirstChildElement("persona").getValue();
			
			
			//coordenadas
			Element coordenadasNacimiento = hijo.getFirstChildElement("coordenadasNacimiento");//cogemos todas las coordenadas 
			Double latitud = Double.parseDouble(coordenadasNacimiento.getFirstChildElement("latitud").getValue());
			Double longitud = Double.parseDouble(coordenadasNacimiento.getFirstChildElement("longitud").getValue());
			
			Double[] coorR = new Double[2];
			coorR[0] = latitud;
			coorR[1] = longitud;
			
			//coordenadas
			Element coordenadasFallecimiento = hijo.getFirstChildElement("coordenadasFallecimiento");//cogemos todas las coordenadas 
			Double latitudF = Double.parseDouble(coordenadasNacimiento.getFirstChildElement("latitud").getValue());
			Double longitudF = Double.parseDouble(coordenadasNacimiento.getFirstChildElement("longitud").getValue());
			
			Double[] coorRF = new Double[2];
			coorR[0] = latitudF;
			coorR[1] = longitudF;
			
			
			
			//personas.add(new Persona(nombre, apellidos, fnac, lugarNacimiento, coorR, lugarFallecimiento, ffa, coorRF, fotografia, comentarios, padre, madre);			
		}
		return personas;
	}
	

	

}
