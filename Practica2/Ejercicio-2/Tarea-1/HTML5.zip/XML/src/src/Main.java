package src;

import java.io.File;
import java.io.*;


public class Main {

	public static void main(String[] args) {
		HTML html = new HTML();//generamos el String q contiene el fichero HTML
		String nuevoHtml = html.getFicheroFinal();
		
		
		FileWriter ficheroDeSalida = null;
        PrintWriter pw = null;
        try
        {
        	ficheroDeSalida = new FileWriter("ficheros/rutas.html");
            pw = new PrintWriter(ficheroDeSalida);

            pw.write(nuevoHtml);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
           try {
           // Nuevamente aprovechamos el finally para 
           // asegurarnos que se cierra el fichero.
           if (null != ficheroDeSalida)
        	   ficheroDeSalida.close();
           } catch (Exception e2) {
              e2.printStackTrace();
           }
        }
	   }
	}


