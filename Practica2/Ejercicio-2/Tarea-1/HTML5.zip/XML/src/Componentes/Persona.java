package Componentes;

import java.util.Date;

public class Persona {
	String nombre;
	String apellidos;
	Date fechaNacimiento;
	String lugarNacimiento;
	Double[] coordenadasNacimiento = new Double[2];
	String lugarFallecimiento;
	Date fechaFallecimiento;
	Double[] coordenadasFallecimiento = new Double[2];
	Fotos fotografia;
	String comentarios;
	Persona padre;
	Persona madre;
	public Persona(String nombre, String apellidos, Date fechaNacimiento, String lugarNacimiento,
			Double[] coordenadasNacimiento, String lugarFallecimiento, Date fechaFallecimiento,
			Double[] coordenadasFallecimiento, Fotos fotografia, String comentarios, Persona padre, Persona madre) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fechaNacimiento = fechaNacimiento;
		this.lugarNacimiento = lugarNacimiento;
		this.coordenadasNacimiento = coordenadasNacimiento;
		this.lugarFallecimiento = lugarFallecimiento;
		this.fechaFallecimiento = fechaFallecimiento;
		this.coordenadasFallecimiento = coordenadasFallecimiento;
		this.fotografia = fotografia;
		this.comentarios = comentarios;
		this.padre = padre;
		this.madre = madre;
	}
	public String getNombre() {
		return nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public Date getFehcaNacimiento() {
		return fechaNacimiento;
	}
	public String getLugarNacimiento() {
		return lugarNacimiento;
	}
	public Double getCoordenadasNacimiento(int i) {
		return coordenadasNacimiento[i];
	}
	public String getLugarFallecimiento() {
		return lugarFallecimiento;
	}
	public Double getCoordenadasFallecimiento(int i) {
		return coordenadasFallecimiento[i];
	}
	public Fotos getFotografia() {
		return fotografia;
	}
	public String getComentarios() {
		return comentarios;
	}
	public Persona getPadre() {
		return padre;
	}
	public Persona getMadre() {
		return madre;
	}
	
}
