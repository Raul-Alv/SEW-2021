package Componentes;

public class Fotos {
	String link;

	public Fotos(String link) {
		super();
		this.link = link;
	}

	@Override
	public String toString() {
		return link ;
	}
	
	
}
